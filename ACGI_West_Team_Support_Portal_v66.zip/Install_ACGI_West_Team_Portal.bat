@echo off
setlocal
cd /d %~dp0
call mysql_config.bat
echo Installing MySQL connector...
python -m pip install --upgrade mysql-connector-python
if errorlevel 1 (echo Failed to install MySQL connector. & pause & exit /b 1)
echo Initializing local MySQL database on %ACGI_MYSQL_HOST%:%ACGI_MYSQL_PORT%...
python setup_mysql.py
if errorlevel 1 (echo Could not connect to local MySQL. Verify MySQL 5.7 is running on port 3307 and root password is correct. & pause & exit /b 1)
start "ACGI West Team Portal" /min cmd /c "call mysql_config.bat && python server.py"
timeout /t 2 >nul
start "" http://localhost:8765
endlocal
