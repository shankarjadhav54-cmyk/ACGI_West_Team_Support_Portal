ACGI WEST REGION TEAM - LOCAL DATABASE PORTAL

This version adds a local SQLite database and local web server. No MySQL installation is required.

1. Install Python 3 on the laptop if it is not already installed.
2. Double-click start_portal.bat.
3. Open http://localhost:8765 in Chrome/Edge.
4. Default login: SRJ / 123
5. The database file is created automatically as acgi_west_team.db in this folder.

The portal keeps a browser copy for fast UI operation and synchronizes the main portal data to SQLite. Calls, project activities, users, profile, handover notes and current-user state are stored in the database.

Backup:
- Use Data / Backup inside the portal for a JSON application backup.
- Copy acgi_west_team.db for a complete local SQLite database backup while the server is stopped.

For multiple laptops/users or centralized access, the next step should be a LAN/server deployment with proper authentication and role permissions.
