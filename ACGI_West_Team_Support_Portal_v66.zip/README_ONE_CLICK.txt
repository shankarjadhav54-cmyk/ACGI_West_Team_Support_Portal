ACGI WEST TEAM PORTAL - ONE CLICK SETUP

1. Install Python 3.14 from https://www.python.org/downloads/
   During installation, tick: Add python.exe to PATH

2. Double-click Install_ACGI_West_Team_Portal.bat once.
   This creates a Desktop shortcut: ACGI West Team Portal

3. From then on, double-click the Desktop shortcut.

4. The portal opens at http://localhost:8765

Default login:
Username: SRJ
Password: 123

The SQLite database is stored in this folder as acgi_west_team.db.
No paid software or database server is required.
