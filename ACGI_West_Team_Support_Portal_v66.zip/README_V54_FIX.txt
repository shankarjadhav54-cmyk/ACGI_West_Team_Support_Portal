V54 FIXES
- AMC Customers and PM Follow-up now use the proper entry modals.
- PM Follow-up AMC Customer is a dropdown populated from AMC Customers.
- Selecting an AMC customer auto-fills Site/Location and No. of Systems.
- Editing/adding AMC customers refreshes the PM customer list.
- PM add/edit no longer uses browser prompt dialogs.
