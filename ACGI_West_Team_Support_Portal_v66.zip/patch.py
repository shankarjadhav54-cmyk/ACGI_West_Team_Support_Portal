from pathlib import Path
p=Path('/mnt/data/v51work/index.html')
s=p.read_text()
# sidebar: remove AMC from dynamic insertion? Existing AMC is injected via addNav, so adjust addNav function string.
s=s.replace("const nav=document.querySelector('.nav');if(!nav)return; if(document.getElementById('navAmcCustomers'))return; const b=document.createElement('button'); b.id='navAmcCustomers';b.dataset.page='amccustomers';b.textContent='👥  AMC Customers'; nav.appendChild(b);", "const nav=document.querySelector('.nav');if(!nav)return; if(document.getElementById('navAmcCore'))return; const group=document.createElement('div'); group.id='navAmcCore'; group.className='navgroup'; group.textContent='AMC CORE'; nav.appendChild(group); const b=document.createElement('button'); b.id='navAmcCustomers';b.dataset.page='amccustomers';b.textContent='👥  AMC Customers'; nav.appendChild(b); const pm=document.createElement('button'); pm.id='navPmFollow';pm.dataset.page='pmfollow';pm.textContent='🛠  PM Follow-up'; nav.appendChild(pm);")
# If exact string differs, do broader replacement
if 'navAmcCore' not in s:
    s=s.replace("const b=document.createElement('button'); b.id='navAmcCustomers';", "const group=document.createElement('div'); group.id='navAmcCore'; group.className='navgroup'; group.textContent='AMC CORE'; nav.appendChild(group); const b=document.createElement('button'); b.id='navAmcCustomers';")
# remove static PM button from MODULES
s=s.replace('<button data-page="pmfollow">🛠 &nbsp; PM Follow-up</button>','')
# PM section replacement
old='<section id="pmfollow" class="page"><div class="section-head"><h2>🛠 PM Follow-up</h2><button class="btn primary" onclick="addPM()">＋ Add PM Follow-up</button></div><div class="grid"><div class="card kpi"><small>PM Due</small><strong id="pmDue">0</strong></div><div class="card kpi"><small>PM Planned</small><strong id="pmPlanned">0</strong></div><div class="card kpi"><small>PM Completed</small><strong id="pmCompleted">0</strong></div><div class="card kpi"><small>Overdue</small><strong id="pmOverdue">0</strong></div></div><div class="section"><div class="tablebox"><table><thead><tr><th>Customer</th><th>Site</th><th>Machine / System</th><th>PM Due</th><th>Engineer</th><th>Status</th><th>Remarks</th></tr></thead><tbody id="pmTable"></tbody></table></div></div></section>'
new='<section id="pmfollow" class="page"><div class="section-head"><div><h2>🛠 PM Follow-up</h2><div class="muted">AMC preventive-maintenance visit planning and completion tracking</div></div><div class="actions-inline"><button class="btn secondary csv-template-btn" onclick="exportCSVTemplate(\'pmfollow\')">⇩ CSV Template</button><button class="btn secondary" onclick="exportPMCSV()">Export CSV</button><button class="btn primary" onclick="addPM()">＋ Add PM Visit</button></div></div><div class="grid"><div class="card kpi"><small>Total AMC Customers</small><strong id="pmCustomers">0</strong></div><div class="card kpi"><small>Total PM Visits</small><strong id="pmVisits">0</strong></div><div class="card kpi"><small>Planned</small><strong id="pmPlanned">0</strong></div><div class="card kpi"><small>Completed</small><strong id="pmCompleted">0</strong></div><div class="card kpi"><small>Pending</small><strong id="pmDue">0</strong></div><div class="card kpi"><small>Overdue</small><strong id="pmOverdue">0</strong></div></div><div class="filters"><input id="pmSearch" placeholder="Search customer, site, engineer, system..." oninput="renderPM()"><select id="pmStatusFilter" onchange="renderPM()"><option value="">All Status</option><option>Planned</option><option>Completed</option><option>Cancelled</option></select></div><div class="section"><div class="tablebox"><table><thead><tr><th>Customer</th><th>Site</th><th>No. of Systems</th><th>No. of PM Visit</th><th>Visit Planned Date</th><th>Visit Completed Date</th><th>Engineer</th><th>Status</th><th>Remarks</th><th>Action</th></tr></thead><tbody id="pmTable"></tbody></table></div></div></section>'
if old not in s: print('PM old not found')
else: s=s.replace(old,new)
# insert PM functions before V41 patch marker
marker='/* V41 Module Navigation + Sample Data Stability Patch */'
pm=r'''
/* V51 AMC Core + PM Visit Tracker */
(function(){
  const PM_KEY='westPmVisits';
  const todayISO=()=>new Date().toISOString().slice(0,10);
  const readPM=()=>{try{const d=JSON.parse(localStorage.getItem(PM_KEY)||'[]');return Array.isArray(d)?d:[]}catch(e){return[]}};
  const savePM=d=>localStorage.setItem(PM_KEY,JSON.stringify(d));
  const esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
  function seedPM(){
    let d=readPM();
    if(d.length)return;
    d=[
      {id:'PM-001',customer:'Lupin Ltd.',site:'Nagpur',systemCount:8,pmVisits:4,plannedDate:'2026-10-05',completedDate:'',engineer:'Rahul Patil',status:'Planned',remarks:'Q3 preventive maintenance'},
      {id:'PM-002',customer:'Ajanta Pharma',site:'Paithan',systemCount:6,pmVisits:3,plannedDate:'2026-09-20',completedDate:'2026-09-21',engineer:'Milind Lokhane',status:'Completed',remarks:'All planned systems covered'},
      {id:'PM-003',customer:'Zydus Lifesciences',site:'Goa',systemCount:4,pmVisits:2,plannedDate:'2026-10-15',completedDate:'',engineer:'Rahul Patil',status:'Planned',remarks:'Coordinate with plant IT'}
    ]; savePM(d);
  }
  window.renderPM=function(){
    const d=readPM(); const q=(document.getElementById('pmSearch')?.value||'').toLowerCase(); const sf=document.getElementById('pmStatusFilter')?.value||'';
    const filtered=d.filter(x=>(!q||[x.customer,x.site,x.engineer,x.systemCount,x.pmVisits].some(v=>String(v??'').toLowerCase().includes(q)))&&(!sf||x.status===sf));
    const today=todayISO(); const planned=d.filter(x=>x.status==='Planned').length; const completed=d.filter(x=>x.status==='Completed').length; const overdue=d.filter(x=>x.status==='Planned'&&x.plannedDate&&x.plannedDate<today).length;
    const customers=new Set(d.map(x=>x.customer).filter(Boolean)).size; const visits=d.reduce((n,x)=>n+(Number(x.pmVisits)||0),0);
    ['pmCustomers','pmVisits','pmPlanned','pmCompleted','pmDue','pmOverdue'].forEach((id,i)=>document.getElementById(id)&&(document.getElementById(id).textContent=[customers,visits,planned,completed,planned,overdue][i]));
    const t=document.getElementById('pmTable'); if(!t)return;
    t.innerHTML=filtered.map(x=>`<tr><td><strong>${esc(x.customer)}</strong></td><td>${esc(x.site)||'-'}</td><td>${Number(x.systemCount)||0}</td><td>${Number(x.pmVisits)||0}</td><td>${esc(x.plannedDate)||'-'}</td><td>${esc(x.completedDate)||'-'}</td><td>${esc(x.engineer)||'-'}</td><td>${x.status==='Completed'?'<span class="pill closed">Completed</span>':x.status==='Cancelled'?'<span class="pill p4">Cancelled</span>':'<span class="pill open">Planned</span>'}</td><td>${esc(x.remarks)||'-'}</td><td><button class="btn secondary small" onclick="editPM('${x.id}')">Edit</button>${isAdmin()?` <button class="btn secondary small" onclick="deletePM('${x.id}')">Delete</button>`:''}</td></tr>`).join('')||'<tr><td colspan="10" class="empty">No PM visits found.</td></tr>';
  };
  window.addPM=function(id=null){
    const d=readPM(), old=id?d.find(x=>x.id===id):null;
    const customer=prompt('AMC Customer:',old?.customer||''); if(!customer?.trim())return;
    const site=prompt('Site / Location:',old?.site||'');
    const systemCount=Math.max(0,parseInt(prompt('No. of Systems:',old?.systemCount||'1'),10)||0);
    const pmVisits=Math.max(0,parseInt(prompt('No. of PM Visit:',old?.pmVisits||'1'),10)||0);
    const plannedDate=prompt('Visit Planned Date (YYYY-MM-DD):',old?.plannedDate||todayISO());
    const completedDate=prompt('Visit Completed Date (YYYY-MM-DD, blank if pending):',old?.completedDate||'');
    const engineer=prompt('Engineer:',old?.engineer||'');
    const status=completedDate?'Completed':(prompt('Status (Planned / Completed / Cancelled):',old?.status||'Planned')||'Planned');
    const remarks=prompt('Remarks:',old?.remarks||'');
    const item={id:old?.id||'PM-'+Date.now().toString().slice(-8),customer:customer.trim(),site:site||'',systemCount,pmVisits,plannedDate:plannedDate||'',completedDate:completedDate||'',engineer:engineer||'',status,remarks:remarks||''};
    if(old){const i=d.findIndex(x=>x.id===id);d[i]=item}else d.push(item); savePM(d);renderPM();
  };
  window.editPM=id=>addPM(id);
  window.deletePM=function(id){if(!isAdmin())return alert('Admin access required.');if(!confirm('Delete this PM visit record?'))return;savePM(readPM().filter(x=>x.id!==id));renderPM()};
  window.exportPMCSV=function(){const d=readPM();const heads=['Customer','Site','No. of Systems','No. of PM Visit','Visit Planned Date','Visit Completed Date','Engineer','Status','Remarks'];const rows=d.map(x=>[x.customer,x.site,x.systemCount,x.pmVisits,x.plannedDate,x.completedDate,x.engineer,x.status,x.remarks]);downloadFile('ACGI_AMC_PM_Followup.csv',[heads,...rows].map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\n'),'text/csv')};
  const oldTemplate=window.exportCSVTemplate; window.exportCSVTemplate=function(type){ if(type==='pmfollow'){const heads=['Customer','Site','No. of Systems','No. of PM Visit','Visit Planned Date','Visit Completed Date','Engineer','Status','Remarks'];downloadFile('ACGI_PM_Followup_Template.csv',heads.join(',')+'\n','text/csv');return;} if(oldTemplate)oldTemplate(type); };
  seedPM(); renderPM();
})();
'''
s=s.replace(marker,pm+'\n'+marker)
# title maps include amc/pm already; role UI: make AMC Core visible for admin and engineer, PM allowed too
s=s.replace("['dashboard','calls','tracker','amccustomers','profile'].includes(b.dataset.page)", "['dashboard','calls','tracker','amccustomers','pmfollow','profile'].includes(b.dataset.page)")
# add PM render on showPage stable wrapper
s=s.replace("if(id==='amccustomers' && typeof window.renderCustomers==='function') window.renderCustomers();", "if(id==='amccustomers' && typeof window.renderCustomers==='function') window.renderCustomers(); if(id==='pmfollow' && typeof window.renderPM==='function') window.renderPM();")
# template list earlier at line 72 add pmfollow if present
s=s.replace("pmfollow:['Customer','Site','Machine / System','PM Due','Engineer','Status','Remarks'],", "pmfollow:['Customer','Site','No. of Systems','No. of PM Visit','Visit Planned Date','Visit Completed Date','Engineer','Status','Remarks'],")
p.write_text(s)
