@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 server.py
  exit /b
)
where python >nul 2>&1
if %errorlevel%==0 (
  python server.py
  exit /b
)
echo Python is not installed.
echo Please install Python 3.14 from https://www.python.org/downloads/
pause
