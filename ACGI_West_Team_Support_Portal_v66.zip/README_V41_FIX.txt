V41 MODULE NAVIGATION + SAMPLE DATA FIX

Login: SRJ / 123
Sample Engineer: ENG001 / 123456
Sample Engineer: ENG002 / 123456

V41 fixes dynamic module navigation and adds sample users, AMC customers and AMC dues.
Admin SRJ has access to all modules and Role Management.
Engineers can access Dashboard, DSR, Open/In Process, AMC Customers and My Profile.
