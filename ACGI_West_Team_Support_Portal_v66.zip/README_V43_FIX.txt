V43 Login Fix
- Fixed embedded script termination in Excel backup generation.
- Added independent login button handlers before portal initialization.
- Default Admin: SRJ / 123.
- Enter key works on password field.
