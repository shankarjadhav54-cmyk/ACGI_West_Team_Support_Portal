V40 fix: role/session propagation corrected so the logged-in user's Admin/Engineer role is preserved after login. Default SRJ account is Admin. This restores Admin module visibility and access after sign-in.
Default login: SRJ / 123
