@echo off
call "%~dp0Run_ACGI_West_Team_Portal.bat"
