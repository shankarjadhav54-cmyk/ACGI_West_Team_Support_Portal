import json, os
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
from datetime import datetime

try:
    import mysql.connector
except ImportError:
    mysql = None

ROOT=os.path.dirname(os.path.abspath(__file__))
PORT=8765
DB_HOST=os.environ.get('ACGI_MYSQL_HOST','127.0.0.1')
DB_PORT=int(os.environ.get('ACGI_MYSQL_PORT','3307'))
DB_USER=os.environ.get('ACGI_MYSQL_USER','root')
DB_PASSWORD=os.environ.get('ACGI_MYSQL_PASSWORD','tnt123')
DB_NAME=os.environ.get('ACGI_MYSQL_DATABASE','acgi_west_team')

def db():
    if mysql is None:
        raise RuntimeError('mysql-connector-python is not installed. Run Install_ACGI_West_Team_Portal.bat.')
    return mysql.connector.connect(host=DB_HOST,port=DB_PORT,user=DB_USER,password=DB_PASSWORD,database=DB_NAME,autocommit=False)

def now(): return datetime.now().isoformat(timespec='seconds')

def init_db():
    if mysql is None: return
    # Database is created by the setup SQL/batch. Create tables here as a safety net.
    c=db(); cur=c.cursor()
    stmts=[
      '''CREATE TABLE IF NOT EXISTS users (id VARCHAR(100) PRIMARY KEY, full_name VARCHAR(255) NOT NULL, employee_code VARCHAR(100) NOT NULL UNIQUE, mobile VARCHAR(50), email VARCHAR(255) UNIQUE, designation VARCHAR(255), shift VARCHAR(100), password VARCHAR(255) NOT NULL, role VARCHAR(50) DEFAULT 'Engineer', created_at VARCHAR(40) NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS calls (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS projects (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS amc_customers (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS pm_visits (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS user_rights (employee_code VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS amc_dues (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS non_amc_followups (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS settings (`key_name` VARCHAR(100) PRIMARY KEY, value_json LONGTEXT, updated_at VARCHAR(40) NOT NULL)'''
    ]
    for s in stmts: cur.execute(s)
    c.commit(); c.close()

def rows_json(cur, table):
    cur.execute(f'SELECT data_json FROM {table} ORDER BY updated_at, id')
    out=[]
    for (raw,) in cur.fetchall():
        try: out.append(json.loads(raw))
        except: pass
    return out

def snapshot():
    c=db(); cur=c.cursor()
    cur.execute('SELECT id,full_name,employee_code,mobile,email,designation,shift,password,role FROM users ORDER BY created_at')
    users=[]
    for r in cur.fetchall():
        users.append({'id':r[0],'fullName':r[1],'employeeCode':r[2],'mobile':r[3] or '', 'email':r[4] or '', 'designation':r[5] or '', 'shift':r[6] or '', 'password':r[7], 'role':r[8] or 'Engineer'})
    calls=rows_json(cur,'calls'); projects=rows_json(cur,'projects'); amc=rows_json(cur,'amc_customers'); pm=rows_json(cur,'pm_visits'); dues=rows_json(cur,'amc_dues'); nonamc=rows_json(cur,'non_amc_followups')
    rights={}; cur.execute('SELECT employee_code,data_json FROM user_rights')
    for code,raw in cur.fetchall():
        try: rights[code]=json.loads(raw)
        except: rights[code]={}
    extras={}
    cur.execute('SELECT key_name,value_json FROM settings WHERE key_name IN (\'profile\',\'handover\',\'currentUser\')')
    for k,v in cur.fetchall():
        try: extras[k]=json.loads(v) if k!='handover' else v
        except: extras[k]={}
    c.close()
    return {'users':users,'calls':calls,'projects':projects,'amcCustomers':amc,'pmVisits':pm,'userRights':rights,'amcDues':dues,'nonAmcFollowups':nonamc,'profile':extras.get('profile',{}),'handover':extras.get('handover',''),'currentUser':extras.get('currentUser',{})}

def replace_json_table(cur, table, data, key='id'):
    cur.execute(f'DELETE FROM {table}')
    ts=now()
    for x in data or []:
        xid=str(x.get(key) or x.get('id') or ('REC-'+str(abs(hash(json.dumps(x,sort_keys=True))))))
        cur.execute(f'INSERT INTO {table}(id,data_json,updated_at) VALUES(%s,%s,%s)',(xid,json.dumps(x,separators=(',',':')),ts))

def save_snapshot(d):
    c=db(); cur=c.cursor(); ts=now()
    try:
        # Users are upserted, never deleted by an empty browser snapshot.
        for u in d.get('users',[]) or []:
            code=str(u.get('employeeCode') or '').strip()
            if not code: continue
            uid=str(u.get('id') or ('USR-'+str(abs(hash(code)))))
            email=str(u.get('email') or '').strip().lower() or None
            cur.execute('''INSERT INTO users(id,full_name,employee_code,mobile,email,designation,shift,password,role,created_at) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE full_name=VALUES(full_name),mobile=VALUES(mobile),email=VALUES(email),designation=VALUES(designation),shift=VALUES(shift),password=VALUES(password),role=VALUES(role)''',(uid,u.get('fullName',''),code,u.get('mobile',''),email,u.get('designation',''),u.get('shift',''),str(u.get('password','')),u.get('role','Engineer'),ts))
        if 'calls' in d: replace_json_table(cur,'calls',d.get('calls') or [])
        if 'projects' in d: replace_json_table(cur,'projects',d.get('projects') or [])
        if 'amcCustomers' in d: replace_json_table(cur,'amc_customers',d.get('amcCustomers') or [])
        if 'pmVisits' in d: replace_json_table(cur,'pm_visits',d.get('pmVisits') or [])
        if 'amcDues' in d: replace_json_table(cur,'amc_dues',d.get('amcDues') or [])
        if 'nonAmcFollowups' in d: replace_json_table(cur,'non_amc_followups',d.get('nonAmcFollowups') or [])
        if 'userRights' in d:
            cur.execute('DELETE FROM user_rights')
            for code,rights in (d.get('userRights') or {}).items():
                cur.execute('INSERT INTO user_rights(employee_code,data_json,updated_at) VALUES(%s,%s,%s)',(str(code),json.dumps(rights,separators=(',',':')),ts))
        for k in ('profile','handover','currentUser'):
            if k in d:
                v=d.get(k) if k=='handover' else json.dumps(d.get(k) or {},separators=(',',':'))
                cur.execute('INSERT INTO settings(key_name,value_json,updated_at) VALUES(%s,%s,%s) ON DUPLICATE KEY UPDATE value_json=VALUES(value_json),updated_at=VALUES(updated_at)',(k,v,ts))
        c.commit()
    except Exception:
        c.rollback(); raise
    finally: c.close()

class Handler(SimpleHTTPRequestHandler):
    def end_json(self,code,payload):
        raw=json.dumps(payload).encode(); self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(raw))); self.send_header('Access-Control-Allow-Origin','*'); self.end_headers(); self.wfile.write(raw)
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS'); self.send_header('Access-Control-Allow-Headers','Content-Type'); self.end_headers()
    def do_GET(self):
        path=urlparse(self.path).path
        try:
            if path=='/api/health': return self.end_json(200,{'ok':True,'database':'MySQL','host':DB_HOST,'port':DB_PORT,'name':DB_NAME})
            if path=='/api/snapshot': return self.end_json(200,snapshot())
        except Exception as e: return self.end_json(500,{'ok':False,'error':str(e)})
        return super().do_GET()
    def do_POST(self):
        path=urlparse(self.path).path; n=int(self.headers.get('Content-Length','0') or 0)
        try: data=json.loads(self.rfile.read(n) or b'{}')
        except Exception: return self.end_json(400,{'ok':False,'error':'Invalid JSON'})
        if path=='/api/snapshot':
            try: save_snapshot(data); return self.end_json(200,{'ok':True,'savedAt':now(),'database':'MySQL'})
            except Exception as e: return self.end_json(500,{'ok':False,'error':str(e)})
        return self.end_json(404,{'ok':False,'error':'Not found'})
    def log_message(self,fmt,*args): print('%s - %s' % (self.address_string(),fmt%args))

if __name__=='__main__':
    if mysql is None:
        print('ERROR: mysql-connector-python is missing.')
        raise SystemExit(1)
    init_db(); os.chdir(ROOT)
    print('ACGI West Team Portal: http://localhost:%d' % PORT)
    print('Database: MySQL on %s:%d / %s' % (DB_HOST,DB_PORT,DB_NAME))
    ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()
