import os, mysql.connector
HOST=os.environ.get('ACGI_MYSQL_HOST','127.0.0.1')
PORT=int(os.environ.get('ACGI_MYSQL_PORT','3307'))
USER=os.environ.get('ACGI_MYSQL_USER','root')
PASSWORD=os.environ.get('ACGI_MYSQL_PASSWORD','tnt123')
NAME=os.environ.get('ACGI_MYSQL_DATABASE','acgi_west_team')
cn=mysql.connector.connect(host=HOST,port=PORT,user=USER,password=PASSWORD)
cur=cn.cursor()
cur.execute(f"CREATE DATABASE IF NOT EXISTS `{NAME}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
cur.close(); cn.close()
cn=mysql.connector.connect(host=HOST,port=PORT,user=USER,password=PASSWORD,database=NAME)
cur=cn.cursor()
stmts=[
"CREATE TABLE IF NOT EXISTS users (id VARCHAR(100) PRIMARY KEY, full_name VARCHAR(255) NOT NULL, employee_code VARCHAR(100) NOT NULL UNIQUE, mobile VARCHAR(50), email VARCHAR(255) UNIQUE, designation VARCHAR(255), shift VARCHAR(100), password VARCHAR(255) NOT NULL, role VARCHAR(50) DEFAULT 'Engineer', created_at VARCHAR(40) NOT NULL)",
"CREATE TABLE IF NOT EXISTS calls (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)",
"CREATE TABLE IF NOT EXISTS projects (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)",
"CREATE TABLE IF NOT EXISTS amc_customers (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)",
"CREATE TABLE IF NOT EXISTS pm_visits (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)",
"CREATE TABLE IF NOT EXISTS user_rights (employee_code VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)",
"CREATE TABLE IF NOT EXISTS amc_dues (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)",
"CREATE TABLE IF NOT EXISTS non_amc_followups (id VARCHAR(100) PRIMARY KEY, data_json LONGTEXT NOT NULL, updated_at VARCHAR(40) NOT NULL)",
"CREATE TABLE IF NOT EXISTS settings (`key_name` VARCHAR(100) PRIMARY KEY, value_json LONGTEXT, updated_at VARCHAR(40) NOT NULL)"
]
for s in stmts: cur.execute(s)
cn.commit(); cur.close(); cn.close()
print(f"Connected successfully to MySQL {HOST}:{PORT}, database={NAME}")
